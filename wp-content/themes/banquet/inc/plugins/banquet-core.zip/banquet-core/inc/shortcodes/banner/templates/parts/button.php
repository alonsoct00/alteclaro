<div class="qodef-m-button">
	<?php echo BanquetCoreButtonShortcode::call_shortcode( $button_params ); ?>
</div>