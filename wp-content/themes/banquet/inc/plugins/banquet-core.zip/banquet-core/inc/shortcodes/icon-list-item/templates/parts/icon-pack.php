<?php

if ( $icon_type == 'icon-pack' ) {
	echo BanquetCoreIconShortcode::call_shortcode( $icon_params );
}