<?php
banquet_core_get_header_logo_image();
banquet_core_template_part( 'header', 'templates/parts/navigation' );
?>
<div class="qodef-widget-holder">
	<?php banquet_core_get_header_widget_area(); ?>
</div>
