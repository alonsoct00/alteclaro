<?php

include_once 'standard.php';