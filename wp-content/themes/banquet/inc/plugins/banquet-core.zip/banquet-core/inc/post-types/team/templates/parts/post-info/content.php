<div class="qodef-team-member-content">
	<?php the_content(); ?>
</div>