<?php

include 'search-opener.php';