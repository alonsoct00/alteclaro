<a id="qodef-back-to-top" href="#">
    <span class="qodef-back-to-top-icon">
		<svg x="0px" y="0px"
			 width="11.83px" height="7.293px" viewBox="-327.781 63.431 11.83 7.293" enable-background="new -327.781 63.431 11.83 7.293"
			 xml:space="preserve">
			<g id="Layer_2_copy">
				<g>
			
						<line fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" x1="-321.866" y1="63.931" x2="-327.281" y2="70.224"/>
			
						<line fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" x1="-316.451" y1="70.224" x2="-321.866" y2="63.931"/>
				</g>
			</g>
		</svg>
    </span>
</a>