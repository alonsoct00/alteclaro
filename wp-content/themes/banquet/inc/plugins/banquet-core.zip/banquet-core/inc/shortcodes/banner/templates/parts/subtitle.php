<?php if ( ! empty( $subtitle ) ) : ?>
	<p  class="qodef-m-subtitle" <?php qode_framework_inline_style( $subtitle_styles ); ?>>
	<?php echo esc_html( $subtitle ); ?>
	</p>
<?php endif; ?>