<?php

include_once 'info-standard.php';